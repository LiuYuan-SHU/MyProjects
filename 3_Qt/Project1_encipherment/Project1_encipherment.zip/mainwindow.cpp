﻿#include "mainwindow.h"
#include "./MD5/MD5.h"
#include "./SHA/SHA256.h"
#include "./SHA/SHA_Tools.h"

#include <QString>
#include <QBoxLayout>
#include <QDebug>

using namespace Liuyuan;

bool MainWindow::isEmpty(QString &text)
{
    if (text.isEmpty())
    {
        this->_page_log->insertHtml(
                    "<center>"
                        "<b>"
                            "<font face=\"JetBrains Mono\" size=\"4\" color=\"red\">"
                                "Your text is empty!<br>"
                                "please input your text before click any button!<br>"
                            "</font>"
                        "</b>"
                    "</center>"
                    );
        return true;
    }
    return false;
}

MainWindow::MainWindow(QWidget *parent)
    : QDialog(parent)
{ 
    //init main window
    this->resize(800,600);
    this->setWindowTitle("Encipherment");
    
    //init text windows
    this->_page_text = new QTextEdit();
    this->_page_password = new QTextEdit();
    this->_page_log = new QTextEdit();
    
    //init buttons
    //_button_MD5
    this->_button_MD5 = new QPushButton("MD5", this);
    this->_button_MD5->setFont(QFont("JetBrains Mono", 18, QFont::Black, true));
    //_button_SHA
    this->_button_SHA = new QPushButton("SHA", this);
    this->_button_SHA->setFont(QFont("JetBrains Mono", 18, QFont::Black, true));
    //_button_DES
    this->_button_DES = new QPushButton("DES", this);
    this->_button_DES->setFont(QFont("JetBrains Mono", 18, QFont::Black, true));
    //_button_AES
    //this->_button_AES = new QPushButton("AES", this);
    //this->_button_AES->setFont(QFont("JetBrains Mono", 18, QFont::Black, true));
    //_button_RSA
    this->_button_RSA = new QPushButton("RSA", this);
    this->_button_RSA->setFont(QFont("JetBrains Mono", 18, QFont::Black, true));
    //_button_close
    this->_button_close = new QPushButton("Close", this);
    this->_button_close->setFont(QFont("JetBrains Mono", 18, QFont::Black, true));
    
    //横向排列加密方式选择按钮
    QHBoxLayout *topButtonLayout = new QHBoxLayout();
    topButtonLayout->addWidget(this->_button_MD5);
    topButtonLayout->addWidget(this->_button_SHA);
    topButtonLayout->addWidget(this->_button_DES);
    //topButtonLayout->addWidget(this->_button_AES);
    topButtonLayout->addWidget(this->_button_RSA);
    
    //组合按钮和明文窗口
    QVBoxLayout *topTextLayout = new QVBoxLayout();
    topTextLayout->addWidget(this->_page_text);
    topTextLayout->addLayout(topButtonLayout);
    
    //放置close按钮
    QHBoxLayout *belowButtonLayout = new QHBoxLayout();
    belowButtonLayout->addWidget(this->_button_close);
    
    //组合close按钮和密码输出窗口
    QVBoxLayout *belowTextLayout = new QVBoxLayout();
    belowTextLayout->addWidget(this->_page_password);
    belowTextLayout->addLayout(belowButtonLayout);
    
    //纵向排列好左边的界面
    QVBoxLayout *leftLayout = new QVBoxLayout();
    leftLayout->addLayout(topTextLayout);
    leftLayout->addLayout(belowTextLayout);
    
    //右边的字符界面好像有点大，调整一下宽度
    this->_page_log->setMaximumWidth(350);
    
    //横向排列好整个界面
    QHBoxLayout *mainLayout = new QHBoxLayout();
    mainLayout->addLayout(leftLayout);
    mainLayout->addWidget(this->_page_log);
    setLayout(mainLayout);
    
    //page init
    this->_page_text->setPlaceholderText("输入明文");
    this->_page_password->setPlaceholderText("打印密码");
    this->_page_password->setReadOnly(true);
    this->_page_log->setPlaceholderText("程序log");
    this->_page_log->setReadOnly(true);
    
    //connect
    //close the program
    connect(this->_button_MD5, QPushButton::clicked, this, this->onMD5);
    connect(this->_button_SHA, QPushButton::clicked, this, this->onSHA);
    connect(this->_button_DES, QPushButton::clicked, this, this->onDES);
    //connect(this->_button_AES, QPushButton::clicked, this, this->onAES);
    connect(this->_button_RSA, QPushButton::clicked, this, this->onRSA);
    //move the cursor to the end of text
    connect(this->_page_log, SIGNAL(textChanged()),this, SLOT(onLogTextChanged()));
    //connect close
    connect(this->_button_close, QPushButton::clicked, this, close);
}

MainWindow::~MainWindow()
{
}

void MainWindow::onMD5()
{
    this->_page_password->clear();
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "---------- SLOT onMD5 ----------<br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
    QString text = this->_page_text->toPlainText();
    if(MainWindow::isEmpty(text)) { return; }
    
    static ZhouPengfei::my_md5 m;
    //将text从QString转换为char*,传给接口函数
    m.MD5(text.toLocal8Bit());
    this->_page_log->setTextColor(QColorConstants::Black);
    this->_page_log->insertPlainText(QString("Your digest: "));
    for(int i = 0; i <= 3; i++)
    {
        this->_page_log->insertPlainText(QString::number(m.get_lGroup()[i],16).toUpper());
    }
    this->_page_log->insertPlainText("\n");
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "--------------------------------<br><br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
}

void MainWindow::onSHA()
{
    this->_page_password->clear();
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "---------- SLOT onSHA ----------<br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
    
    QString text = this->_page_text->toPlainText();
    if(MainWindow::isEmpty(text)) { return; }
    if(text.length() >= 1000) 
    {
        this->_page_log->insertHtml(
                    "<center>"
                        "<b>"
                            "<font face=\"JetBrains Mono\" size=\"4\" color=\"red\">"
                                "Your text is too long (longer than 1000)!<br>"
                            "</font>"
                        "</b>"
                    "</center>"
                    );
        return;
    }
    
    XvJianchao::PAD((unsigned char*)text.toLocal8Bit().toUpper().data());
    XvJianchao::M_D = XvJianchao::sha256.DEAL(XvJianchao::M);
    this->_page_log->setTextColor(QColorConstants::Black);
    this->_page_log->insertPlainText("Your Digest:");
    for(int i = 0; i < 8; i++) { this->_page_log->insertPlainText(QString::number(XvJianchao::M_D.H[i]).toUpper()); }
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "<br>--------------------------------<br><br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
}

void MainWindow::onDES()
{
    this->_page_password->clear();
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "---------- SLOT onDES ----------<br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
}

void MainWindow::onAES()
{
    this->_page_password->clear();
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "---------- SLOT onAES ----------<br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
}

void MainWindow::onRSA()
{
    this->_page_password->clear();
    this->_page_log->insertHtml(
                "<center>"
                    "<b>"
                        "<font face=\"JetBrains Mono\" size=\"4\" color=\"blue\">"
                            "---------- SLOT onRSA ----------<br>"
                        "</font>"
                    "</b>"
                "</center>"
                );
}

void MainWindow::onLogTextChanged()
{
    this->_page_log->moveCursor(QTextCursor::End);
}

